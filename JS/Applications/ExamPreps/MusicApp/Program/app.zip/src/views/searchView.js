export function searchView(ctx){
    console.log('search work');
}