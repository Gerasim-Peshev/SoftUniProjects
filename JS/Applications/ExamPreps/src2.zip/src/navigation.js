import{html, render} from './lib.js'
import { getUserData } from "./util.js";

export async function updateNav(){

    const user = getUserData();

    render(navTemp(user), headers);
}

const headers = document.querySelector('header');

const navTemp = (user) => html`

`;