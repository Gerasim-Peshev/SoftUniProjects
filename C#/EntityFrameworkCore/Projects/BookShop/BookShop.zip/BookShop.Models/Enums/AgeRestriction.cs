﻿namespace BookShop.Models.Enums
{
    public enum AgeRestriction
    {
        Minor = 0,
        Teen = 1,
        Adult = 2
    }
}
