﻿namespace Trucks.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-UAJSSJ3\SQLEXPRESS01;Database=Trucks;Trusted_Connection=True";
    }
}