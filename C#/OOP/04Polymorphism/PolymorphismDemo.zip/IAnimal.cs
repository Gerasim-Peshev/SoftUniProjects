﻿namespace PolymorphismDemo
{
    public interface IAnimal
    {
        void Move();
    }
}
