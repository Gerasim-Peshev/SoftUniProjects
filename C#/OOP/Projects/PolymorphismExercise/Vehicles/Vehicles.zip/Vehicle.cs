﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vehicles
{
    public abstract class Vehicle
    {
        public abstract double FuelQuantity { get; set; }
        public abstract double FuelConsumption { get; set; }

        public abstract bool Drive(double kilometres);

        public abstract void Refuel(double litres);
    }
}
