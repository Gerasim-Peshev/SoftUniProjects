﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vehicles
{
    public class Truck : Vehicle
    {
        public Truck(double fuelQuantity, double fuelConsumption)
        {
            this.FuelQuantity = fuelQuantity;
            this.FuelConsumption = fuelConsumption + 1.6;
        }
        public override double FuelQuantity { get; set; }
        public override double FuelConsumption { get; set; }
        public override bool Drive(double kilometres)
        {
            if (this.FuelQuantity - (this.FuelConsumption * kilometres) >= 0)
            {
                this.FuelQuantity -= this.FuelConsumption * kilometres;
                return true;
            }

            return false;
        }

        public override void Refuel(double litres)
        {
            this.FuelQuantity += litres * 0.95;
        }
    }
}
