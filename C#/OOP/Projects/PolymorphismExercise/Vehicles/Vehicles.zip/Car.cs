﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vehicles
{
    public class Car : Vehicle
    {
        public Car(double fuelQuantity, double litresPerKm)
        {
            this.FuelQuantity = fuelQuantity;
            this.FuelConsumption = litresPerKm + 0.9;
        }

        public override double FuelQuantity { get; set; }
        public override double FuelConsumption { get; set; }

        public override bool Drive(double kilometres)
        {
            if (this.FuelQuantity - (this.FuelConsumption * kilometres) >= 0)
            {
                this.FuelQuantity -= this.FuelConsumption * kilometres;
                return true;
            }
            return false;
        }

        public override void Refuel(double litres)
        {
            this.FuelQuantity += litres;
        }
    }
}
