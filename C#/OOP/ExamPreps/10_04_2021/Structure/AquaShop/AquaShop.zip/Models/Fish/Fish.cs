﻿using System;
using System.Collections.Generic;
using System.Text;
using AquaShop.Models.Fish.Contracts;

namespace AquaShop.Models.Fish
{
    public abstract class Fish : IFish
    {
        public Fish(string name, string species, decimal price)
        {
            
        }
        public string Name { get; }
        public string Species { get; }
        public int Size { get; }
        public decimal Price { get; }
        public abstract void Eat();

    }
}
