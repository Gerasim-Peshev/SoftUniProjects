﻿using System;
using System.Collections.Generic;
using System.Text;
using AquaShop.Models.Aquariums.Contracts;
using AquaShop.Models.Decorations.Contracts;
using AquaShop.Models.Fish.Contracts;

namespace AquaShop.Models.Aquariums
{
    public abstract class Aquarium : IAquarium
    {
        public Aquarium(string name, int capacity)
        {
            
        }
        public string Name { get; }
        public int Capacity { get; }
        public int Comfort { get; }
        public ICollection<IDecoration> Decorations { get; }
        public ICollection<IFish> Fish { get; }
        public void AddFish(IFish fish)
        {
            throw new NotImplementedException();
        }

        public bool RemoveFish(IFish fish)
        {
            throw new NotImplementedException();
        }

        public void AddDecoration(IDecoration decoration)
        {
            throw new NotImplementedException();
        }

        public void Feed()
        {
            throw new NotImplementedException();
        }

        public string GetInfo()
        {
            throw new NotImplementedException();
        }
    }
}
