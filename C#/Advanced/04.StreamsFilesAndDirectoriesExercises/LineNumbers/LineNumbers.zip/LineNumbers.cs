﻿using System.Collections.Generic;
using System.IO;
using System.Text;

namespace LineNumbers
{
    using System;
    public class LineNumbers
    {
        static void Main(string[] args)
        {
            string inputPath = @"..\..\..\text.txt";
            string outputPath = @"..\..\..\output.txt";

            ProcessLines(inputPath, outputPath);
        }

        public static void ProcessLines(string inputFilePath, string outputFilePath)
        {
            var lines = File.ReadAllLines(inputFilePath);

            var sb = new List<string>();
            for (int i = 0; i < lines.Length; i++)
            {
                var line = lines[i];
                int counterLetters = 0;
                int countPunkst = 0;

                foreach (var c in line)
                {
                    if (char.IsLetter(c))
                    {
                        counterLetters++;
                    }
                    else if (char.IsPunctuation(c))
                    {
                        countPunkst++;
                    }
                }

                sb.Add($"Line {i + 1}: {line} ({counterLetters})({countPunkst})");
            }

            File.WriteAllLines(outputFilePath,sb);
        }
    }
}

